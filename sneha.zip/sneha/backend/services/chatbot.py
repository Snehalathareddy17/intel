import json
import os
from .. import models
from typing import List

# Load data on startup
DATA_PATH = os.path.join(os.path.dirname(__file__), "../data/knowledge_base.json")

def load_knowledge_base() -> List[dict]:
    with open(DATA_PATH, "r") as f:
        return json.load(f)

KNOWLEDGE_BASE = load_knowledge_base()

def get_response(message: str) -> str:
    message = message.lower()
    
    # Simple keyword matching logic for the MVP
    # In a real app, this would use an LLM or vector search
    
    found_universities = []
    
    for uni in KNOWLEDGE_BASE:
        if uni["university_name"].lower() in message:
            found_universities.append(uni)
            
    if not found_universities:
         # Fallback search by program if university not found directly
        for uni in KNOWLEDGE_BASE:
            for prog in uni["programs"]:
                if prog["name"].lower() in message or prog["degree"].lower() in message:
                     if uni not in found_universities:
                        found_universities.append(uni)

    if not found_universities:
        return "I'm sorry, I couldn't find any information deeply matching your query in my current database. I know about Stanford, MIT, and UC Berkeley. Try asking about 'Stanford CS requirements' or 'MIT Data Science'."

    response_text = ""
    
    for uni in found_universities:
        response_text += f"**{uni['university_name']}** ({uni['location']})\n\n"
        
        relevant_programs = []
        for prog in uni["programs"]:
            # If the user asked about a specific program, filter
            if prog["name"].lower() in message or prog["degree"].lower() in message or "programs" in message or "courses" in message or len(found_universities) == 1:
                 relevant_programs.append(prog)
        
        # If no specific program matched but we found the university, show all or list them
        if not relevant_programs and "requirement" not in message:
             response_text += "Programs available:\n"
             for p in uni["programs"]:
                 response_text += f"- {p['name']}\n"
             response_text += "\n"

        for prog in relevant_programs:
            response_text += f"__Program: {prog['name']}__\n"
            response_text += f"- **Degree**: {prog['degree']}\n"
            response_text += f"- **Duration**: {prog['duration']}\n"
            response_text += f"- **Tuition**: {prog['tuition']}\n"
            
            if "deadline" in message:
                response_text += f"- **Deadlines**: {', '.join([f'{k}: {v}' for k,v in prog['deadlines'].items()])}\n"
            
            if "requirement" in message or "criteria" in message or "eligibility" in message:
                reqs = prog['requirements']
                response_text += "- **Requirements**:\n"
                for k, v in reqs.items():
                    if v:
                        formatted_key = k.replace("_", " ").title()
                        response_text += f"  - {formatted_key}: {v}\n"
            
            response_text += f"\n{prog['description']}\n\n"

    return response_text.strip()
