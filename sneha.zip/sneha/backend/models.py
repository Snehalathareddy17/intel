from pydantic import BaseModel
from typing import List, Dict, Optional

class Requirement(BaseModel):
    gpa: Optional[str] = None
    gre: Optional[str] = None
    toefl: Optional[str] = None
    letters_of_recommendation: Optional[int] = None
    statement_of_purpose: Optional[str] = None
    resume: Optional[str] = None
    work_experience: Optional[str] = None
    essays: Optional[str] = None
    prerequisites: Optional[str] = None
    research_experience: Optional[str] = None
    degree: Optional[str] = None # Added for flexibility

class Program(BaseModel):
    name: str
    degree: str
    duration: str
    tuition: str
    deadlines: Dict[str, str]
    requirements: Requirement
    description: str

class University(BaseModel):
    university_name: str
    location: str
    programs: List[Program]

class ChatRequest(BaseModel):
    message: str

class ChatResponse(BaseModel):
    response: str
    # metadata: Optional[Dict] = None # For future use to send structured data back
