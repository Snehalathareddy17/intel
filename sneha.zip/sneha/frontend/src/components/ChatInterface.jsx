import React, { useState, useRef, useEffect } from 'react';
import './ChatInterface.css';

const ChatInterface = () => {
    const [messages, setMessages] = useState([
        { id: 1, text: "Hello! I'm your University Admissions Assistant. Ask me about programs, requirements, or deadlines for Stanford, MIT, or UC Berkeley.", sender: 'bot' }
    ]);
    const [inputText, setInputText] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const messagesEndRef = useRef(null);

    const scrollToBottom = () => {
        messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
    };

    useEffect(() => {
        scrollToBottom();
    }, [messages]);

    const handleSendMessage = async (e) => {
        e.preventDefault();
        if (!inputText.trim()) return;

        const userMessage = { id: Date.now(), text: inputText, sender: 'user' };
        setMessages(prev => [...prev, userMessage]);
        setInputText('');
        setIsLoading(true);

        try {
            const response = await fetch('http://localhost:8000/chat', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ message: userMessage.text }),
            });

            if (!response.ok) {
                throw new Error('Network response was not ok');
            }

            const data = await response.json();
            const botMessage = { id: Date.now() + 1, text: data.response, sender: 'bot' };
            setMessages(prev => [...prev, botMessage]);
        } catch (error) {
            console.error('Error:', error);
            const errorMessage = { id: Date.now() + 1, text: "Sorry, I'm having trouble connecting to the server. Please ensure the backend is running.", sender: 'bot', isError: true };
            setMessages(prev => [...prev, errorMessage]);
        } finally {
            setIsLoading(false);
        }
    };

    // Helper to render markdown-like bolding and lists simply
    const renderMessageText = (text) => {
        return text.split('\n').map((line, i) => {
            // Check for bold text **text**
            const parts = line.split(/(\*\*.*?\*\*|__.*?__)/g);
            return (
                <div key={i} className="message-line">
                    {parts.map((part, j) => {
                        if (part.startsWith('**') && part.endsWith('**')) {
                            return <strong key={j}>{part.slice(2, -2)}</strong>;
                        } else if (part.startsWith('__') && part.endsWith('__')) {
                            return <em key={j} style={{ fontWeight: '600', color: '#646cff' }}>{part.slice(2, -2)}</em>;
                        }
                        return part;
                    })}
                </div>
            );
        });
    };

    return (
        <div className="chat-container">
            <header className="chat-header">
                <h1>🎓 Admissions Bot</h1>
            </header>

            <div className="messages-area">
                {messages.map((msg) => (
                    <div key={msg.id} className={`message-wrapper ${msg.sender}`}>
                        <div className={`message-bubble ${msg.sender} ${msg.isError ? 'error' : ''}`}>
                            {renderMessageText(msg.text)}
                        </div>
                    </div>
                ))}
                {isLoading && (
                    <div className="message-wrapper bot">
                        <div className="message-bubble bot typing-indicator">
                            <span></span><span></span><span></span>
                        </div>
                    </div>
                )}
                <div ref={messagesEndRef} />
            </div>

            <form className="input-area" onSubmit={handleSendMessage}>
                <input
                    type="text"
                    value={inputText}
                    onChange={(e) => setInputText(e.target.value)}
                    placeholder="Ask about admission requirements..."
                    disabled={isLoading}
                />
                <button type="submit" disabled={isLoading || !inputText.trim()}>
                    <svg viewBox="0 0 24 24" width="24" height="24" fill="currentColor">
                        <path d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z"></path>
                    </svg>
                </button>
            </form>
        </div>
    );
};

export default ChatInterface;
